#include <stdio.h>

int main() {
    int m, n;
    printf("Enter the number of rows : ");
    scanf("%d", &m);
    printf("Enter the number of columns : ");
    scanf("%d", &n);

    int matrix[m][n];
    printf("Enter matrix elements:\n", m, n);
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
    long long product = 1;

    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if (i == 0 || i == m - 1 || j == 0 || j == n - 1) {
                product *= matrix[i][j];
            }
        }
    }
    printf("Product is: %lld\n", product);

    return 0;
}
