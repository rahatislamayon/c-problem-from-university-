// #include <stdio.h>

int main() {
    int input = 7; 
    for (int i = 0; i < input; i++) {
        printf("Z");
    }
    printf("\n");
    for (int i = 1; i < input - 1; i++) {
        for (int j = 0; j < i; j++) {
            printf(" ");
        }
        printf("Z\n");
    }

    for (int i = 0; i < input; i++) {
        printf("Z");
    }

    return 0;
}
